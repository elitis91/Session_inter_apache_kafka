package com.tutorial.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class NoAuthConsumer {
	
	@KafkaListener(topics = "montopic", groupId = "no_auth")
	public void receivedMessage(ConsumerRecord<String, String> record) {
		System.out.println("Received message : " + record.value());
		System.out.println("---- TERMINE ----");
	}

}
